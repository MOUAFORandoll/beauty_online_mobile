import 'package:flutter/material.dart';
import '../widgets/status_bar.dart';
import '../widgets/search_tabs.dart';
import '../widgets/content_grid.dart';
import '../widgets/bottom_navigation.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // Status Bar Custom Widget
            const StatusBar(
              time: "21:00",
              batteryPercentage: 80,
              isLTE: true,
            ),
            
            // Search Tabs
            const SearchTabs(
              tabs: ["Tout", "Appli"],
              searchQuery: "Coupe cheveux afro homme",
            ),
            
            // Main Content Grid
            const Expanded(
              child: ContentGrid(),
            ),
            
            // Bottom Navigation
            const BottomNavigation(),
          ],
        ),
      ),
    );
  }
}
