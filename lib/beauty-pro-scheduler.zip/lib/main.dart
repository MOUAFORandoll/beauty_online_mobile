import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'cubit/schedule_cubit.dart';
import 'screens/schedule_list_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ScheduleCubit(),
      child: MaterialApp(
        title: 'Beauty Pro Scheduler',
        theme: ThemeData(
          primarySwatch: Colors.purple,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          fontFamily: 'Roboto',
          appBarTheme: AppBarTheme(
            backgroundColor: Colors.purple[800],
            elevation: 0,
          ),
        ),
        home: const ScheduleListScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
